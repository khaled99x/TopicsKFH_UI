import React from "react";
import Login from "./pages/login";

function App() {
  return (
    
      <div className="App">
        <Login/>
    </div>
  );
}

export default App;
