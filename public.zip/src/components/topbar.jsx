import { Toolbar, Typography } from "@mui/material";
import logo from '../assets/images/logo.jpeg';

export default function TopBar()
{
    return (
        <>
            <Toolbar>
                <Typography variant="h6" sx={{ flexGrow: 1, textAlign: 'center' }}>
                    <img src={logo} className="App-logo" alt="logo" />
                </Typography>
            </Toolbar>
        </>
    );
}